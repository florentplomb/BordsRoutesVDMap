'use strict';

module.exports = function (grunt, options) {
    return {
        install: {
          //  options: {
          //      targetDir: './bower_components',
          //      cleanup: true
          //  }
        }
    };
};
