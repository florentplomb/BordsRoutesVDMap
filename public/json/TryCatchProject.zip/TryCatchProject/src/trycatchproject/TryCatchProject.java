/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trycatchproject;

import java.util.ArrayList;

/**
 *
 * @author ariellem
 */
public class TryCatchProject {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
            ArrayList<String> arrayList = new ArrayList();
            //arrayList.add("first"); 
            System.out.println("Elément à l'indice 0: " + arrayList.get(0));
        }catch(Exception e){
            System.out.println("Il n'y a aucun élément à l'indice 0: " + e.toString());
        }finally{
            System.out.println("Fin");
        }
    }
    
}
